<?php
// FILE: admin/index.php
require_once('../core/db.php');
?><!DOCTYPE html>
<html lang="ar" dir="rtl">
<head><meta charset="UTF-8"><title>لوحة التحكم</title></head><body><h2>لوحة تحكم المعلم الإلكتروني</h2></body></html>