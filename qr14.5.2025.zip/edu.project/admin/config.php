<?php
// FILE: /edu.project/admin/config.php
// 🔐 التحكم في تفعيل أو تعطيل حماية الملفات
$enableSecureFile = true; // اجعلها false لتعطيل الحماية مؤقتًا
?>
