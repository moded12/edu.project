<?php
// FILE: view_attachment.php
require_once('../admin/core/db.php');

$lesson_id = intval($_GET['lesson_id'] ?? 0);

// جلب اسم الدرس
$lesson_res = $conn->query("SELECT name FROM lessons WHERE id = $lesson_id");
$lesson = $lesson_res->fetch_assoc();
$lesson_name = $lesson ? $lesson['name'] : 'درس غير معروف';

// جلب أول ملف مرتبط بالدرس
$file_res = $conn->query("SELECT path FROM lesson_files WHERE lesson_id = $lesson_id ORDER BY id ASC LIMIT 1");
$file = $file_res->fetch_assoc();

if ($file && !empty($file['path'])) {
  $fullUrl = 'https://www.shneler.com/edu.project/admin/views/' . ltrim($file['path'], '/');
  header("Location: $fullUrl");
  exit;
} else {
  echo "<h2 style='text-align:center;margin-top:100px;font-family:Cairo,sans-serif;color:red;'>🚫 لا يوجد ملف مرتبط بهذا الدرس.</h2>";
}
?>
