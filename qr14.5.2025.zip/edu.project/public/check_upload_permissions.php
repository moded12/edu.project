<?php
// FILE: check_upload_permissions.php

$paths = [
  '../admin/views/uploads',
  '../admin/views/uploads/lessons',
];

echo "<!DOCTYPE html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'><title>فحص صلاحيات المجلدات</title>
<style>body{font-family:'Cairo',sans-serif;background:#f5f5f5;padding:2rem;color:#333}</style></head><body>";
echo "<h2>🔍 فحص صلاحيات المجلدات المطلوبة لرفع الملفات</h2><ul>";

foreach ($paths as $path) {
  echo "<li><strong>$path</strong>: ";
  if (!file_exists($path)) {
    echo "<span style='color:red'>❌ المجلد غير موجود</span></li>";
  } elseif (!is_writable($path)) {
    echo "<span style='color:orange'>⚠️ موجود ولكن لا يمكن الكتابة عليه (Not Writable)</span></li>";
  } else {
    echo "<span style='color:green'>✅ صالح للكتابة (Writable)</span></li>";
  }
}

echo "</ul></body></html>";
?>
