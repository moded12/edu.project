<?php
// FILE: check_slug_indexes.php
require_once('../admin/core/db.php');

$tables = [
  'applications',
  'classes',
  'materials',
  'semesters',
  'sections',
  'groups',
  'lessons'
];

echo "<!DOCTYPE html><html lang='ar' dir='rtl'><head><meta charset='UTF-8'>
<title>فحص فهارس slug</title>
<style>body{font-family:'Cairo',sans-serif;padding:2rem;background:#f7f7f7}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:8px;text-align:center}th{background:#333;color:#fff}</style>
</head><body>";
echo "<h2>🔍 فحص وجود قيد UNIQUE على حقل slug في الجداول</h2>";
echo "<table><thead><tr><th>الجدول</th><th>النتيجة</th></tr></thead><tbody>";

foreach ($tables as $table) {
  $res = $conn->query("
    SELECT COUNT(*) as total 
    FROM information_schema.statistics 
    WHERE table_schema = DATABASE() 
      AND table_name = '$table' 
      AND index_name = 'slug'
  ");
  $row = $res->fetch_assoc();
  $hasSlug = intval($row['total']) > 0;

  echo "<tr><td>$table</td><td style='color:" . ($hasSlug ? "red" : "green") . "'>" .
       ($hasSlug ? "❌ يوجد قيد slug" : "✅ لا يوجد قيد slug") .
       "</td></tr>";
}

echo "</tbody></table></body></html>";
?>
