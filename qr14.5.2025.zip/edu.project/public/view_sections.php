<?php
// FILE: view_sections.php
require_once('../admin/core/db.php');

$material_id = intval($_GET['material_id'] ?? 0);
$semester_id = intval($_GET['semester'] ?? 0);

// جلب اسم المادة
$material_res = $conn->query("SELECT name FROM materials WHERE id = $material_id");
$material = $material_res->fetch_assoc();
$material_name = $material ? $material['name'] : 'غير معروف';

// جلب اسم الفصل
$semester_res = $conn->query("SELECT name FROM semesters WHERE id = $semester_id");
$semester = $semester_res->fetch_assoc();
$semester_name = $semester ? $semester['name'] : 'غير معروف';

// جلب الأقسام
$sections = $conn->query("SELECT * FROM sections WHERE material_id = $material_id AND semester_id = $semester_id ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>📁 أقسام <?= htmlspecialchars($material_name) ?> - <?= htmlspecialchars($semester_name) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>body { font-family: 'Cairo', sans-serif; }</style>
</head>
<body class="bg-gray-100 text-gray-800 p-6">

  <h1 class="text-2xl font-bold text-center text-indigo-700 mb-6">
    📁 أقسام <?= htmlspecialchars($material_name) ?> - <?= htmlspecialchars($semester_name) ?>
  </h1>

  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
    <?php while ($row = $sections->fetch_assoc()): ?>
      <a href="view_groups.php?section_id=<?= $row['id'] ?>"
         class="block bg-white p-4 rounded-xl shadow hover:shadow-md transition text-center">
        <h2 class="text-lg font-semibold text-indigo-800"><?= htmlspecialchars($row['name']) ?></h2>
      </a>
    <?php endwhile; ?>
    <?php if ($sections->num_rows === 0): ?>
      <div class="col-span-full text-center text-red-500">🚫 لا توجد أقسام لهذا الفصل.</div>
    <?php endif; ?>
  </div>

</body>
</html>
