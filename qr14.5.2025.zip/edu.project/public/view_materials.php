<?php
// FILE: view_materials.php
require_once('../admin/core/db.php');

$class_id = intval($_GET['class_id'] ?? 0);
$class_res = $conn->query("SELECT name FROM classes WHERE id = $class_id");
$class = $class_res->fetch_assoc();
$class_name = $class ? $class['name'] : 'غير معروف';

$materials = $conn->query("SELECT * FROM materials WHERE class_id = $class_id ORDER BY id ASC");

// جلب الفصلين الثابتين مسبقًا
$semesters = $conn->query("SELECT id, name FROM semesters WHERE id IN (10, 11) ORDER BY id ASC");
$semester_data = [];
while ($sem = $semesters->fetch_assoc()) {
  $semester_data[] = $sem;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>📘 مواد <?= htmlspecialchars($class_name) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>body { font-family: 'Cairo', sans-serif; }</style>
</head>
<body class="bg-gray-100 text-gray-800 p-6">

<h1 class="text-2xl font-bold text-center text-green-700 mb-6">📘 مواد <?= htmlspecialchars($class_name) ?></h1>

<div class="space-y-8">
  <?php while ($row = $materials->fetch_assoc()): ?>
    <div class="bg-white rounded-xl shadow p-4">
      <h2 class="text-xl font-semibold text-green-800 mb-2"><?= htmlspecialchars($row['name']) ?></h2>
      <div class="flex flex-wrap gap-3">
        <?php foreach ($semester_data as $sem): ?>
          <a href="view_sections.php?material_id=<?= $row['id'] ?>&semester=<?= $sem['id'] ?>"
             class="px-4 py-2 rounded-lg bg-green-100 text-green-800 hover:bg-green-200 transition">
            <?= htmlspecialchars($sem['name']) ?>
          </a>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endwhile; ?>
</div>

</body>
</html>
