<?php
// FILE: view_semesters.php
require_once('../admin/core/db.php');

$material_id = intval($_GET['material_id'] ?? 0);

$material_res = $conn->query("SELECT name FROM materials WHERE id = $material_id");
$material = $material_res->fetch_assoc();
$material_name = $material ? $material['name'] : 'غير معروف';

// جلب الفصلين من قاعدة البيانات فقط إذا كانا id = 10 أو 11
$semesters = $conn->query("
  SELECT id, name 
  FROM semesters 
  WHERE id IN (10, 11)
  ORDER BY id ASC
");
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>📆 فصول مادة <?= htmlspecialchars($material_name) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>body { font-family: 'Cairo', sans-serif; }</style>
</head>
<body class="bg-gray-100 text-gray-800 p-6">

  <h1 class="text-2xl font-bold text-center text-purple-700 mb-6">📘 فصول مادة <?= htmlspecialchars($material_name) ?></h1>

  <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
    <?php while ($semester = $semesters->fetch_assoc()): ?>
      <a href="view_sections.php?material_id=<?= $material_id ?>&semester=<?= $semester['id'] ?>"
         class="block bg-white p-4 rounded-xl shadow hover:shadow-md transition text-center">
        <h2 class="text-lg font-semibold text-purple-800">📆 <?= htmlspecialchars($semester['name']) ?></h2>
      </a>
    <?php endwhile; ?>
  </div>

</body>
</html>
