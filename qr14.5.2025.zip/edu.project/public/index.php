<?php
// FILE: /edu.project/public/index.php
require_once('../admin/core/db.php');
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>📘 المعلم الإلكتروني</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: { cairo: ['Cairo', 'sans-serif'] }
        }
      }
    }
  </script>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
  <style> body { font-family: 'Cairo', sans-serif; } </style>
</head>
<body class="bg-gray-100 min-h-screen">

  <header class="bg-blue-700 text-white py-4 text-center text-2xl font-bold shadow mb-6">
    📘 اختر الصف
  </header>

  <div class="container mx-auto max-w-3xl p-4">
    <div id="mainContent">
      <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <?php
        $res = $conn->query("SELECT * FROM classes ORDER BY id ASC");
        while ($row = $res->fetch_assoc()):
          $class_id = $row['id'];
          $class_name = htmlspecialchars($row['name']);
          echo "
            <div onclick=\"loadMaterials($class_id)\"
                 class='bg-white border border-blue-100 rounded-lg p-3 shadow-sm hover:shadow-md transition text-center cursor-pointer'>
              <h2 class='text-base font-bold text-blue-800'>$class_name</h2>
            </div>";
        endwhile;
        ?>
      </div>
    </div>
  </div>

  <script>
    function loadMaterials(classId) {
      const main = document.getElementById('mainContent');
      main.innerHTML = '<div class="text-center p-6 text-gray-500">⏳ جارٍ تحميل المواد...</div>';
      fetch(`view_materials.php?class_id=${classId}`)
        .then(response => response.text())
        .then(html => {
          main.innerHTML = html;
        })
        .catch(error => {
          main.innerHTML = '<div class="text-red-500 text-center p-6">❌ حدث خطأ أثناء تحميل المواد.</div>';
          console.error(error);
        });
    }
  </script>

</body>
</html>