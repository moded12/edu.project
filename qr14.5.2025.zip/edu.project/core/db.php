<?php
$host = 'localhost';
$user = 'edu.project';
$pass = 'Tvvcrtv1610@';
$dbname = 'edu.project';
$conn = new mysqli($host, $user, $pass, $dbname);
mysqli_set_charset($conn, 'utf8mb4');
?>